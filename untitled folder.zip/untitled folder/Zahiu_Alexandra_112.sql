-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 21, 2025 at 08:33 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Zahiu_Alexandra_112`
--

-- --------------------------------------------------------

--
-- Table structure for table `Apelanti`
--

CREATE TABLE `Apelanti` (
  `id_apelant` int(11) NOT NULL,
  `nume` varchar(100) DEFAULT NULL,
  `prenume` varchar(100) DEFAULT NULL,
  `adresa` varchar(255) DEFAULT NULL,
  `numar_apelant` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Apelanti`
--

INSERT INTO `Apelanti` (`id_apelant`, `nume`, `prenume`, `adresa`, `numar_apelant`) VALUES
(1, 'Popescu', 'Ion', 'Str. Principala, nr. 10, București', '0722334455'),
(2, 'Popescu', 'Andrei', 'Strada Libertății 5', '0741234567'),
(3, 'Ionescu', 'Maria', 'Strada Unirii 10', '0759876543'),
(4, 'Vasile', 'Ioana', 'Strada Călărași 2', '0741122334'),
(5, 'Matei', 'Adrian', 'Str. Mihai Bravu, Nr. 14, Galați', '0731000001'),
(6, 'Constantinescu', 'Elena', 'Str. Teiului, Nr. 8, Ploiești', '0732000002'),
(7, 'Cojocaru', 'Liviu', 'Str. Bradului, Nr. 22, Sibiu', '0733000003'),
(8, 'Sandu', 'Carmen', 'Str. Trandafirului, Nr. 18, Oradea', '0734000004'),
(9, 'Ilie', 'George', 'Str. Fagului, Nr. 6, Iași', '0735000005'),
(10, 'Dumitru', 'Alina', 'Strada Mihai Viteazul 12', '0747654321'),
(11, 'Marinescu', 'George', 'Strada Horia 45', '0751234567'),
(12, 'Radu', 'Cristina', 'Strada Decebal 23', '0765432198'),
(13, 'Ionescu', 'Andrei', '112 Iuliu Maniu', '0766660021'),
(16, 'Ion', 'Maria', 'Lujerului 75', '0722345678'),
(17, 'Popescu', 'Petrica', 'Mtii Carpati', '0789573569'),
(18, 'MARIA', 'MARIA', 'MARIA 52', '0722222222'),
(25, 'oop', 'ooop', 'ooooop', '0745645645'),
(26, 'test', 'test', 'Strada Principala nr 10', '0788998899');

-- --------------------------------------------------------

--
-- Table structure for table `Apeluri`
--

CREATE TABLE `Apeluri` (
  `id_apel` int(11) NOT NULL,
  `numar_apelant` varchar(20) DEFAULT NULL,
  `ora_apel` datetime DEFAULT NULL,
  `tip_incident` varchar(255) DEFAULT NULL,
  `status_apel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Apeluri`
--

INSERT INTO `Apeluri` (`id_apel`, `numar_apelant`, `ora_apel`, `tip_incident`, `status_apel`) VALUES
(1, '0722334455', '2024-11-08 08:30:00', 'Accident rutier', 'deschis'),
(2, '0741234567', '2025-01-07 10:30:00', 'Accident rutier', 'deschis'),
(3, '0759876543', '2024-11-15 11:00:00', 'Incendiu într-o clădire', 'în progres'),
(4, '0741122334', '2024-11-15 11:15:00', 'Leșin', 'închis'),
(5, '0731000001', '2024-11-20 13:10:00', 'Explozie', 'deschis'),
(6, '0732000002', '2024-11-21 10:15:00', 'Accident industrial', 'in progres'),
(7, '0733000003', '2024-11-21 18:00:00', 'Scurgere de gaze', 'închis'),
(8, '0734000004', '2024-11-22 08:30:00', 'Persoană dispărută', 'deschis'),
(9, '0735000005', '2024-11-22 12:00:00', 'Tâlhărie', 'închis'),
(10, '0747654321', '2024-11-15 12:00:00', 'Avarie gaz', 'în progres'),
(11, '0751234567', '2024-11-15 12:30:00', 'Persoană blocată în lift', 'deschis'),
(12, '0765432198', '2024-11-15 13:00:00', 'Incident rutier minor', 'închis'),
(13, '0766411233', '2021-09-12 12:12:12', 'accident', 'desfasurare'),
(14, '0722443556', '2024-12-10 20:20:20', 'Accident', 'deschis'),
(15, '0766413889', '2025-01-08 09:25:26', 'Accident', 'În Progres'),
(16, '0766660021', '2025-01-08 09:38:43', 'Accident', 'În Progres'),
(19, '0722345678', '2025-01-16 09:01:13', 'Accident', 'Deschis'),
(20, '0789573569', '2025-01-16 09:17:45', 'Accident', 'În Progres'),
(21, '0722222222', '2025-01-16 11:58:11', 'Altele', 'Deschis'),
(28, '0745645645', '2025-01-16 16:54:20', 'Accident', 'În Progres'),
(29, '0788998899', '2025-01-21 21:30:38', 'Accident', 'În Progres');

-- --------------------------------------------------------

--
-- Table structure for table `Echipamente`
--

CREATE TABLE `Echipamente` (
  `id_echipament` int(11) NOT NULL,
  `denumire` varchar(100) DEFAULT NULL,
  `tip_echipament` varchar(50) DEFAULT NULL,
  `id_interventie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Echipamente`
--

INSERT INTO `Echipamente` (`id_echipament`, `denumire`, `tip_echipament`, `id_interventie`) VALUES
(1, 'Defibrilator', 'medical', 1),
(2, 'Defibrilator', 'medical', 1),
(3, 'Mașină de pompieri', 'vehicul', 2),
(4, 'Ambulanță', 'vehicul', 3),
(16, 'test', 'test', 6);

-- --------------------------------------------------------

--
-- Table structure for table `Interventii`
--

CREATE TABLE `Interventii` (
  `id_interventie` int(11) NOT NULL,
  `id_apel` int(11) DEFAULT NULL,
  `ora_start` datetime DEFAULT NULL,
  `ora_final` datetime DEFAULT NULL,
  `tip_interventie` varchar(100) DEFAULT NULL,
  `status_interventie` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Interventii`
--

INSERT INTO `Interventii` (`id_interventie`, `id_apel`, `ora_start`, `ora_final`, `tip_interventie`, `status_interventie`) VALUES
(1, 1, '2024-11-08 08:35:00', '2024-11-08 09:10:00', 'Ambulanță', 'finalizată'),
(2, 1, '2024-11-15 10:40:00', '2024-11-15 11:00:00', 'Ambulanță', 'finalizată'),
(3, 2, '2024-11-15 11:10:00', '2024-11-15 12:00:00', 'Pompieri', 'în desfășurare'),
(4, 3, '2024-11-15 11:20:00', '2024-11-15 11:50:00', 'Ambulanță', 'finalizată'),
(5, 4, '2024-11-15 12:10:00', '2024-11-15 13:00:00', 'Pompieri', 'în desfășurare'),
(6, 5, '2024-11-15 12:40:00', '2024-11-15 13:10:00', 'Poliție', 'finalizată'),
(7, 6, '2024-11-15 13:15:00', '2024-11-15 14:00:00', 'Ambulanță', 'finalizată'),
(18, 16, '2025-01-08 09:38:43', '2025-01-20 19:49:28', 'Poliție', 'Finalizată'),
(21, 19, '2025-01-16 09:01:13', '2025-01-20 19:49:33', 'Pompieri', 'Finalizată'),
(22, 20, '2025-01-16 09:17:45', '2025-01-20 19:49:40', 'Salvamont', 'Finalizată'),
(23, 21, '2025-01-16 11:58:11', '2025-01-17 21:00:15', 'Ambulanță', 'Finalizată'),
(29, 28, '2025-01-16 16:54:20', '2025-01-20 18:16:44', 'Poliție', 'Finalizată'),
(30, 29, '2025-01-21 21:30:38', NULL, 'Poliție', 'Finalizată');

-- --------------------------------------------------------

--
-- Table structure for table `Inter_pers`
--

CREATE TABLE `Inter_pers` (
  `id_inter_pers` int(11) NOT NULL,
  `id_personal` int(11) DEFAULT NULL,
  `id_interventie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Inter_pers`
--

INSERT INTO `Inter_pers` (`id_inter_pers`, `id_personal`, `id_interventie`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 2, 2),
(4, 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `Locatii_Incidente`
--

CREATE TABLE `Locatii_Incidente` (
  `id_locatie` int(11) NOT NULL,
  `adresa` varchar(255) DEFAULT NULL,
  `coordonate` varchar(50) DEFAULT NULL,
  `id_apel` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Locatii_Incidente`
--

INSERT INTO `Locatii_Incidente` (`id_locatie`, `adresa`, `coordonate`, `id_apel`) VALUES
(1, 'Str. Principala, nr. 10, București', '44.4268,26.1025', 1),
(2, 'Strada Libertății 5', '44.4268, 26.1025', 1),
(3, 'Strada Unirii 10', '44.4268, 26.1025', 2),
(4, 'Strada Călărași 2', '44.4268, 26.1025', 3);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `parola` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `parola`) VALUES
(1, 'utilizator1', 'parola123'),
(2, 'utilizator2', 'parola456'),
(3, 'admin', '123'),
(4, 'aaa', '111'),
(5, 'qqq', '000'),
(7, '111', '000'),
(8, '1234567', '1234567'),
(9, '0', '0'),
(10, '999', '999'),
(11, 'cornel', 'asd123'),
(12, '8989', '8989');

-- --------------------------------------------------------

--
-- Table structure for table `Personal_Interventie`
--

CREATE TABLE `Personal_Interventie` (
  `id_personal` int(11) NOT NULL,
  `nume` varchar(100) DEFAULT NULL,
  `prenume` varchar(100) DEFAULT NULL,
  `functie` varchar(50) DEFAULT NULL,
  `id_unitate` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Personal_Interventie`
--

INSERT INTO `Personal_Interventie` (`id_personal`, `nume`, `prenume`, `functie`, `id_unitate`) VALUES
(1, 'Ionescu', 'Mihai', 'Medic', 1),
(2, 'Georgescu', 'Mihai', 'Medic', 1),
(3, 'Popa', 'Ion', 'Pompier', 2),
(4, 'Ionescu', 'Elena', 'Șofer', 3),
(5, 'Ivan', 'Daniel', 'Agent Poliție', 5),
(6, 'Ciobanu', 'Raluca', 'Asistent Medical', 6);

-- --------------------------------------------------------

--
-- Table structure for table `Raport_Interventii`
--

CREATE TABLE `Raport_Interventii` (
  `id_raport` int(11) NOT NULL,
  `id_interventie` int(11) DEFAULT NULL,
  `descriere` text DEFAULT NULL,
  `recomandari` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Raport_Interventii`
--

INSERT INTO `Raport_Interventii` (`id_raport`, `id_interventie`, `descriere`, `recomandari`) VALUES
(1, 1, 'Intervenția a fost finalizată fără incidente majore.', 'Monitorizare suplimentară a pacientului timp de 24 de ore.'),
(2, 1, 'Intervenție pentru accident rutier cu victime, pacientul a fost stabilizat și transportat la spital.', 'Monitorizare atentă la spital, eventual tratament post-traumatic.'),
(3, 2, 'Intervenție pentru incendiu într-o clădire. Pompierii au evacuat persoanele și au stins focul.', 'Verificări ulterioare pentru siguranța clădirii.'),
(4, 3, 'Leșin raportat. Pacienta a fost evaluată și transportată la spital pentru investigații suplimentare.', 'Investigații medicale pentru stabilirea cauzei leșinului.'),
(5, 5, 'Persoană blocată în lift evacuată de poliție și pompieri, fără victime.', 'Verificarea liftului și sistemului de întreținere.'),
(6, 6, 'Pacient transportat la spital după un accident rutier minor.', 'Recomandare pentru verificări medicale suplimentare.'),
(7, 5, 'nimic', 'nimic'),
(10, 18, 'Nimic', 'Nimic'),
(11, 22, 'Om lesinat pe traseu', 'Snow Ski pentru ridicarea pacientului'),
(12, 5, 'test', 'test'),
(13, 22, 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `Unitati_Interventie`
--

CREATE TABLE `Unitati_Interventie` (
  `id_unitate` int(11) NOT NULL,
  `nume_unitate` varchar(100) DEFAULT NULL,
  `tip_unitate` varchar(50) DEFAULT NULL,
  `id_interventie` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Unitati_Interventie`
--

INSERT INTO `Unitati_Interventie` (`id_unitate`, `nume_unitate`, `tip_unitate`, `id_interventie`) VALUES
(1, 'Ambulanță București', 'Ambulanță', 1),
(2, 'Ambulanță București', 'Ambulanță', 1),
(3, 'Pompieri Sector 3', 'Pompieri', 2),
(4, 'Ambulanță Cluj', 'Ambulanță', 3),
(5, 'Poliție Sector 1', 'Poliție', 5),
(6, 'Ambulanță Ilfov', 'Ambulanță', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Apelanti`
--
ALTER TABLE `Apelanti`
  ADD PRIMARY KEY (`id_apelant`),
  ADD KEY `numar_apelant` (`numar_apelant`);

--
-- Indexes for table `Apeluri`
--
ALTER TABLE `Apeluri`
  ADD PRIMARY KEY (`id_apel`),
  ADD UNIQUE KEY `numar_apelant` (`numar_apelant`);

--
-- Indexes for table `Echipamente`
--
ALTER TABLE `Echipamente`
  ADD PRIMARY KEY (`id_echipament`),
  ADD KEY `id_interventie` (`id_interventie`);

--
-- Indexes for table `Interventii`
--
ALTER TABLE `Interventii`
  ADD PRIMARY KEY (`id_interventie`),
  ADD KEY `id_apel` (`id_apel`);

--
-- Indexes for table `Inter_pers`
--
ALTER TABLE `Inter_pers`
  ADD PRIMARY KEY (`id_inter_pers`),
  ADD KEY `id_personal` (`id_personal`),
  ADD KEY `id_interventie` (`id_interventie`);

--
-- Indexes for table `Locatii_Incidente`
--
ALTER TABLE `Locatii_Incidente`
  ADD PRIMARY KEY (`id_locatie`),
  ADD KEY `id_apel` (`id_apel`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `unique_username` (`username`);

--
-- Indexes for table `Personal_Interventie`
--
ALTER TABLE `Personal_Interventie`
  ADD PRIMARY KEY (`id_personal`),
  ADD KEY `id_unitate` (`id_unitate`);

--
-- Indexes for table `Raport_Interventii`
--
ALTER TABLE `Raport_Interventii`
  ADD PRIMARY KEY (`id_raport`),
  ADD KEY `id_interventie` (`id_interventie`);

--
-- Indexes for table `Unitati_Interventie`
--
ALTER TABLE `Unitati_Interventie`
  ADD PRIMARY KEY (`id_unitate`),
  ADD KEY `id_interventie` (`id_interventie`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Apelanti`
--
ALTER TABLE `Apelanti`
  MODIFY `id_apelant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `Apeluri`
--
ALTER TABLE `Apeluri`
  MODIFY `id_apel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `Echipamente`
--
ALTER TABLE `Echipamente`
  MODIFY `id_echipament` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `Interventii`
--
ALTER TABLE `Interventii`
  MODIFY `id_interventie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `Inter_pers`
--
ALTER TABLE `Inter_pers`
  MODIFY `id_inter_pers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `Locatii_Incidente`
--
ALTER TABLE `Locatii_Incidente`
  MODIFY `id_locatie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `Personal_Interventie`
--
ALTER TABLE `Personal_Interventie`
  MODIFY `id_personal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `Raport_Interventii`
--
ALTER TABLE `Raport_Interventii`
  MODIFY `id_raport` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `Unitati_Interventie`
--
ALTER TABLE `Unitati_Interventie`
  MODIFY `id_unitate` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Apelanti`
--
ALTER TABLE `Apelanti`
  ADD CONSTRAINT `apelanti_ibfk_1` FOREIGN KEY (`numar_apelant`) REFERENCES `Apeluri` (`numar_apelant`);

--
-- Constraints for table `Echipamente`
--
ALTER TABLE `Echipamente`
  ADD CONSTRAINT `echipamente_ibfk_1` FOREIGN KEY (`id_interventie`) REFERENCES `Interventii` (`id_interventie`);

--
-- Constraints for table `Interventii`
--
ALTER TABLE `Interventii`
  ADD CONSTRAINT `interventii_ibfk_1` FOREIGN KEY (`id_apel`) REFERENCES `Apeluri` (`id_apel`);

--
-- Constraints for table `Inter_pers`
--
ALTER TABLE `Inter_pers`
  ADD CONSTRAINT `inter_pers_ibfk_1` FOREIGN KEY (`id_personal`) REFERENCES `Personal_Interventie` (`id_personal`),
  ADD CONSTRAINT `inter_pers_ibfk_2` FOREIGN KEY (`id_interventie`) REFERENCES `Interventii` (`id_interventie`);

--
-- Constraints for table `Locatii_Incidente`
--
ALTER TABLE `Locatii_Incidente`
  ADD CONSTRAINT `locatii_incidente_ibfk_1` FOREIGN KEY (`id_apel`) REFERENCES `Apeluri` (`id_apel`);

--
-- Constraints for table `Personal_Interventie`
--
ALTER TABLE `Personal_Interventie`
  ADD CONSTRAINT `personal_interventie_ibfk_1` FOREIGN KEY (`id_unitate`) REFERENCES `Unitati_Interventie` (`id_unitate`);

--
-- Constraints for table `Raport_Interventii`
--
ALTER TABLE `Raport_Interventii`
  ADD CONSTRAINT `raport_interventii_ibfk_1` FOREIGN KEY (`id_interventie`) REFERENCES `Interventii` (`id_interventie`);

--
-- Constraints for table `Unitati_Interventie`
--
ALTER TABLE `Unitati_Interventie`
  ADD CONSTRAINT `unitati_interventie_ibfk_1` FOREIGN KEY (`id_interventie`) REFERENCES `Interventii` (`id_interventie`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
